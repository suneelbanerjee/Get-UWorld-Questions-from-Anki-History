from aqt import mw
from aqt.qt import *
from aqt.utils import showInfo

# Handle imports for different Anki versions (Qt5 vs Qt6)
try:
    from PyQt6.QtWebEngineCore import QWebEnginePage
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings
except ImportError:
    try:
        from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineView
        from PyQt5.QtWebEngineWidgets import QWebEngineSettings
    except ImportError:
        QWebEngineView = None
        QWebEnginePage = None

class UWorldDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("UWorld", parent)
        self.setObjectName("UWorldDock")
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setMinimumWidth(450) # Set a reasonable default width

        # Main container
        container = QWidget()
        self.setWidget(container)
        
        # Layout
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)

        # Web View Setup
        if QWebEngineView:
            self.web_view = QWebEngineView()
            self.page = UWorldPage(self.web_view)
            self.web_view.setPage(self.page)
            
            # Enable Javascript/Popups for UWorld to work correctly
            settings = self.web_view.settings()
            settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, True)
            
            # Load Login Page
            url = QUrl("https://www.uworld.com/app/index.html#/login")
            self.web_view.setUrl(url)
            
            layout.addWidget(self.web_view)
        else:
            layout.addWidget(QLabel("Error: WebEngine not found. UWorld cannot load."))

class UWorldPage(QWebEnginePage):
    """
    Custom Page logic to handle navigation and new windows.
    Forces links to open inside the same dock widget instead of a new window.
    """
    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        return True

    def createWindow(self, _type):
        # If UWorld tries to open a popup (e.g. for a test), force it 
        # to open in the current view so it stays in the split screen.
        return self

# Global reference to keep the dock alive
uworld_dock = None

def toggle_uworld_sidebar():
    global uworld_dock
    
    # Create the dock if it doesn't exist yet
    if not uworld_dock:
        uworld_dock = UWorldDock(mw)
        
        # Add it to the main window (Right side by default)
        mw.addDockWidget(Qt.RightDockWidgetArea, uworld_dock)
        
        # Ensure it floats if dragged, but starts docked
        uworld_dock.setFloating(False)

    # Toggle visibility
    if uworld_dock.isVisible():
        uworld_dock.hide()
    else:
        uworld_dock.show()

# Add to Tools Menu
action = QAction("Toggle UWorld Sidebar", mw)
action.triggered.connect(toggle_uworld_sidebar)
mw.form.menuTools.addAction(action)