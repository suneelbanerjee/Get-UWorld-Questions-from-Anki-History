# -*- coding: utf-8 -*-
import os
import re
import json
from aqt import mw
from aqt.qt import *
from aqt.utils import showText, tooltip

# ============================================================
# 1) WebEngine Compatibility
# ============================================================
try:
    from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings, QWebEngineProfile
    from PyQt6.QtWebEngineWidgets import QWebEngineView
except ImportError:
    try:
        from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineView, QWebEngineSettings, QWebEngineProfile
    except ImportError:
        QWebEngineView = None
        QWebEnginePage = None
        QWebEngineProfile = None

# ============================================================
# 2) Result Dialog (Simple Copy-Paste)
# ============================================================
class ScanResultDialog(QDialog):
    def __init__(self, ids, parent=None):
        super().__init__(parent)
        self.setWindowTitle("UWorld Missed Questions")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)
        
        layout = QVBoxLayout()
        
        lbl = QLabel(f"Found <b>{len(ids)}</b> Missed Question IDs:")
        layout.addWidget(lbl)
        
        # Text Area
        self.text_area = QTextEdit()
        # Sort numerically
        sorted_ids = sorted(list(ids), key=lambda x: int(x) if x.isdigit() else 0)
        id_str = ", ".join(sorted_ids)
        self.text_area.setPlainText(id_str)
        layout.addWidget(self.text_area)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        btn_copy = QPushButton("Copy to Clipboard")
        btn_copy.clicked.connect(self.copy_to_clip)
        
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        
        btn_layout.addWidget(btn_copy)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)

    def copy_to_clip(self):
        mw.app.clipboard().setText(self.text_area.toPlainText())
        tooltip("Copied!")

# ============================================================
# 3) The UWorld Dock
# ============================================================
class UWorldDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("UWorld", parent)
        self.setObjectName("UWorldDock")
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setMinimumWidth(450)

        container = QWidget()
        self.setWidget(container)
        
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)

        if QWebEngineView:
            self.web_view = QWebEngineView()
            self._setup_profile()
            
            # Start at Login Page
            url = QUrl("https://www.uworld.com/app/index.html#/login")
            self.web_view.setUrl(url)
            
            layout.addWidget(self.web_view)
        else:
            layout.addWidget(QLabel("Error: WebEngine not found."))

    def _setup_profile(self):
        # Persistent Storage for Login Cookies
        base = os.path.dirname(os.path.abspath(__file__))
        spath = os.path.join(base, "uworld_data")
        if not os.path.exists(spath): os.makedirs(spath)

        if QWebEngineProfile:
            self.profile = QWebEngineProfile("UWorldProfile_Clean", self.web_view)
            self.profile.setPersistentStoragePath(spath)
            self.profile.setCachePath(spath)
            # Modern User Agent to prevent throttling
            ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            self.profile.setHttpUserAgent(ua)
            self.page = UWorldPage(self.profile, self.web_view)
        else:
            self.page = UWorldPage(self.web_view)
            
        self.web_view.setPage(self.page)
        settings = self.web_view.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)

    def run_scan(self):
        """Injects the Precision Scraper based on your screenshots."""
        js_code = r"""
        (function() {
            let missedIDs = [];
            
            // 1. Find all "Red X" icons
            // Based on your screenshot: class contains 'fa-times'
            let icons = document.querySelectorAll('.fa-times');
            
            if (icons.length === 0) {
                // Fallback: search for any element with "incorrect" class text
                // But fa-times is the most reliable from your logs
            }

            icons.forEach(icon => {
                // 2. Traverse up to the Row Container (TR or mat-row)
                let row = icon.closest('tr') || icon.closest('.mat-row') || icon.closest('[role="row"]');
                
                if (row) {
                    // 3. Extract text from this row only
                    let text = row.innerText;
                    
                    // 4. Find the Question ID (2 to 7 digits)
                    // We look for strict numbers bounded by spaces or start/end of string
                    // We ignore 'matches' with % or : to avoid dates/scores
                    let matches = text.match(/\b\d{3,7}\b/g);
                    
                    if (matches) {
                        for (let m of matches) {
                            // Filter logic: 
                            // - Ignore "2024", "2025" (Dates)
                            // - Ignore typical small numbers if they look like indexes
                            let num = parseInt(m);
                            
                            // Most UWorld IDs are > 1000. 
                            // If you have low IDs, remove this check.
                            // Also checking context: does the row contain "Expiration"?
                            if (!text.toLowerCase().includes('expiration')) {
                                missedIDs.push(m);
                            }
                        }
                    }
                }
            });
            
            // Remove duplicates
            return [...new Set(missedIDs)];
        })();
        """
        self.web_view.page().runJavaScript(js_code, self.process_results)

    def process_results(self, ids):
        if not ids:
            tooltip("Scan complete. No 'Incorrect' markers (fa-times) found.")
            return
        
        # Open the copy-paste dialog
        dlg = ScanResultDialog(ids, mw)
        dlg.exec()

    def run_debug_html(self):
        """Dumps table HTML to inspect if scan fails."""
        js_code = "document.body.innerHTML"
        self.web_view.page().runJavaScript(js_code, self.show_debug_text)

    def show_debug_text(self, html):
        # Save to desktop for manual inspection if needed
        desk = os.path.expanduser("~/Desktop/uworld_dump.html")
        with open(desk, "w", encoding="utf-8") as f:
            f.write(html)
        showText(f"Saved page HTML to:\n{desk}\n\nIf scan fails, send this file.", title="Debug HTML")

class UWorldPage(QWebEnginePage):
    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        return True
    def createWindow(self, _type):
        return self

# ============================================================
# 4) Menu & Initialization
# ============================================================
uworld_dock = None

def toggle_sidebar():
    global uworld_dock
    if not uworld_dock:
        uworld_dock = UWorldDock(mw)
        mw.addDockWidget(Qt.RightDockWidgetArea, uworld_dock)
        uworld_dock.setFloating(False)
    
    if uworld_dock.isVisible():
        uworld_dock.hide()
    else:
        uworld_dock.show()

def perform_scan():
    if uworld_dock and uworld_dock.isVisible():
        uworld_dock.run_scan()
    else:
        tooltip("Open sidebar first.")

def perform_debug():
    if uworld_dock and uworld_dock.isVisible():
        uworld_dock.run_debug_html()

# Setup Menu
uw_menu = None
for action in mw.form.menuTools.actions():
    if action.text() == "UWorld Helper":
        uw_menu = action.menu()
        break

if not uw_menu:
    uw_menu = mw.form.menuTools.addMenu("UWorld Helper")

uw_menu.clear()
uw_menu.addAction(QAction("Toggle Sidebar", mw, triggered=toggle_sidebar))
uw_menu.addSeparator()
uw_menu.addAction(QAction("Scan for Missed Questions", mw, triggered=perform_scan))
#uw_menu.addAction(QAction("Save Page HTML (Debug)", mw, triggered=perform_debug))